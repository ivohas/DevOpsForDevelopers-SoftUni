﻿namespace TaskBoard.WebApp.Models
{
    public class HomeBoardModel
    {
        public string BoardName { get; init; }
        public int TasksCount { get; init; }
    }
}
